# ✨ SPEEDSMM VERSIYON 5 YAYINDA 1 AYLIK UCRETSIZ KULLANIM ICIN [TIKLA](https://speedsmm.com) ✨

# ✨ SPEEDSMM VERSION 5 IS LIVE FOR 1 MONTH FREE USE [CLICK](https://speedsmm.com) ✨


# Fast_Sms_Bomber_Panel


# ✨Features and projects to be added as stars arrive✨

- ~~Sms Bomber As Terminal -> 0 Stars ✨~~ [Done GitHub Link](https://github.com/fastuptime/Fast_Sms_Bomber)
- ~~Sms Bomber As Discord Bot -> 5 Stars ✨~~ [Done GitHub Link](https://github.com/fastuptime/Fast_Sms_Bomber_Discord)
- ~~Sms Bomber As API -> 10 Stars ✨~~ [Done GitHub Link](https://github.com/fastuptime/Fast_Sms_Bomber_Api)
- ~~Panelled Sms Bomber -> 15 Stars ✨~~ [Done GitHub Link](https://github.com/fastuptime/Fast_Sms_Bomber_Panel)
- ~~Fast Sms Bomber Module Test -> 40 Stars ✨~~ [Done GitHub Link](https://github.com/fastuptime/Fast_Sms_Bomber_Module)

##  🎈 Images 🎈

![image](https://github.com/fastuptime/Fast_Sms_Bomber_Panel/assets/63351166/075896b9-94af-4447-8dd8-a0e809f51ade)
![image](https://github.com/fastuptime/Fast_Sms_Bomber_Panel/assets/63351166/c8c63020-1683-4edc-99da-166eb5200796)
![image](https://github.com/fastuptime/Fast_Sms_Bomber_Panel/assets/63351166/478491cd-1569-4cbd-945a-ad63e6dc4740)
![image](https://github.com/fastuptime/Fast_Sms_Bomber_Panel/assets/63351166/b619197a-4066-4034-8720-07d60c0ee5a6)
![image](https://github.com/fastuptime/Fast_Sms_Bomber_Panel/assets/63351166/94136f35-9fbf-40dc-847d-09992f49a32b)
![image](https://github.com/fastuptime/Fast_Sms_Bomber_Panel/assets/63351166/838eb117-c4a4-4329-a9d8-a559fd682911)
![image](https://github.com/fastuptime/Fast_Sms_Bomber_Panel/assets/63351166/d2245b7f-0b6a-458a-aced-f0f8765dfbca)
![image](https://github.com/fastuptime/Fast_Sms_Bomber_Panel/assets/63351166/5aa1a96a-ff00-4bac-b60c-fb739abeb08d)

## 📜 Notes 📜

- It was made for educational purposes.
- It is an offence to use it for attack purposes.
- For educational purposes, only 10 sites have been utilised for vulnerabilities.
- Sites Captcha / Anti Bot / Etc. You can easily exploit these vulnerabilities because it does not use.
- Sites can use at least Captcha to block such systems.
- Such systems can be done for more than one site. In this way, it can disturb a target.
- In addition, Check the Config File There is something there for you


# 🛠️ Installation 🛠️

- Download and install [NodeJs](https://nodejs.org/en/download) on your computer.
- Download the project as Zip to your computer and unzip it.
- Enter the folder you extracted from the zip and open a terminal to the location of that folder, then enter the following commands.
`npm install`
- Start the bot by entering the following command in Terminal
`node .`

https://www.youtube.com/watch?v=Tk2yuSbWvLk

## ⛳Tech Stack ⛳

**🗄️Server:** Node, Faker, Colors, Request, Express, Cookie Parser, BodyParser, Mongoose, etc.

---
- ✨ [For Support](https://github.com/sponsors/fastuptime) <br>
- 💕 [Discord](https://fastuptime.com/discord)<br>
- 🏓 [Fast Uptime](https://fastuptime.com/)<br>
- 🪄 All kinds of projects are made <br>
- 🧨 You can contact us to make a paid project<br>
- ☄️ [Click For Contact](mailto:fastuptime@gmail.com)<br>

# 🎯 License 🎯
- ⚖️ Its protected by Creative Commons ([CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/))

<a href="https://creativecommons.org/licenses/by-nc-sa/4.0/" title="BYNCSA40"><img src="https://licensebuttons.net/l/by-nc-sa/4.0/88x31.png"></a>
